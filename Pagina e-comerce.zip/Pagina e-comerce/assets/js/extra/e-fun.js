function calcularPrecioFinal(precio, decuentoPorcentaje) {
    const descuento = precio * (decuentoPorcentaje / 100);
    const precioFinal = precio - descuento;
    return precioFinal;
}

function templateCards(nombre,precio,stock) {

    return(
        <>
        
        </>
    )
}