//alert("Alerta desde js");
//asdkjaslkdjsalkdjalkjdaslkdj slakjdlakj salj asjl 
/*
asldkaslkdjaslkd
asdjaskldjalkdasjda
sdjasdasldkasjda
*/
console.log("Hola desde index.js");

const nombreInstructor = "Ezequiel"
const apellidoInstructor = "Mondino"

const nombreCompleto = nombreInstructor + " " + apellidoInstructor

const nombreCompletoMejorado = `${nombreInstructor} ${apellidoInstructor}`

let edad = 1992;


let FN = prompt("Indicame tu fecha de nacimiento:")

let edadUsuario = 2025 - FN

alert("tu edad es: " + edadUsuario)


edad = 30





console.log("mi edad es:" + edad)